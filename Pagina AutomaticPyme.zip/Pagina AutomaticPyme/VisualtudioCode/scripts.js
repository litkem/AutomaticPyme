/* Estas líneas de código seleccionan elementos del documento HTML utilizando sus respectivos ID y
asignándolos a constantes. */
const carrito = document.getElementById('carrito');
const elementos1 = document.getElementById('lista-1');
const elementos2 = document.getElementById('lista-2');
const lista = document.querySelector('#lista-carrito tbody');
const vaciarCarritoBtn = document.getElementById('vaciar-carrito');

cargarEventListeners();

/**
 * Esta función agrega detectores de eventos a diferentes elementos en un carrito de compras.
 */
function cargarEventListeners() {
    elementos1.addEventListener('click', comprarElemento);
    elementos2.addEventListener('click', comprarElemento);
    carrito.addEventListener('click', eliminarElemento);
    vaciarCarritoBtn.addEventListener('click', vaciarCarrito);
}

/**
 * La función agrega un detector de eventos a un botón y lee los datos del elemento seleccionado cuando
 * se hace clic.
 * @param e - El parámetro "e" es un objeto de evento que se pasa a la función "comprarElemento" cuando
 * se llama. Se utiliza para evitar el comportamiento predeterminado de un evento de clic en un botón
 * con la clase "agregar-carrito" y para obtener el elemento padre del botón que
 */
function comprarElemento(e) {
    e.preventDefault();
    if(e.target.classList.contains('agregar-carrito')) {
        const elemento = e.target.parentElement.parentElement;
        leerDatosElemento(elemento);
    }
}

/**
 * La función lee datos de un elemento HTML y los inserta en un carrito de compras.
 * @param elemento - Este parámetro representa un elemento HTML que contiene información sobre un
 * producto, como una imagen, título, precio e ID. La función extrae esta información del elemento y
 * crea un objeto llamado "infoElemento" que luego se pasa a otra función llamada "insertarCarrito".
 */
function leerDatosElemento(elemento){
    const infoElemento = {
        imagen: elemento.querySelector('img').src,
        titulo: elemento.querySelector('h3').textContent,
        precio: elemento.querySelector('.precio').textContent,
        id: elemento.querySelector('a').getAttribute('data-id')
    }
    insertarCarrito(infoElemento);
}

/**
 * La función inserta una nueva fila en una tabla con información sobre un producto y un botón de
 * eliminación.
 * @param elemento - un objeto que contiene información sobre un producto, incluida su imagen, título,
 * precio e ID. La función crea una nueva fila de la tabla (tr) y la completa con esta información,
 * incluido un enlace "X" en el que se puede hacer clic para eliminar el artículo del carrito. Luego se
 * agrega la fila
 */
function insertarCarrito(elemento){

    const row = document.createElement('tr');
    row.innerHTML = `
        <td>
           <img src="${elemento.imagen}" width=100 >
        </td>
        <td>
           ${elemento.titulo}
        </td>
        <td>
           ${elemento.precio}
        </td>
        <td>
           <a herf="#" class="borrar" data-id="${elemento.id}">X</a>
        </td>    
    `;

    lista.appendChild(row);

}

/**
 * La función elimina un elemento del DOM cuando se hace clic en un botón específico y recupera la ID
 * del elemento eliminado.
 * @param e - El objeto de evento que activó la función, que se pasa como argumento cuando se llama a
 * la función.
 */
function eliminarElemento(e) {
    e.preventDefault();
    let elemento,
        elementoId;

    if (e.target.classList.contains('borrar')) {

        e.target.parentElement.parentElement.remove();
        elemento = e.target.parentElement.parentElement;
        elementoId = elemento.querySelector('a').getAttribute('data-id');
    }
}

/**
 * La función vaciarCarrito elimina todos los elementos secundarios del elemento principal "lista".
 * @returns el valor booleano `falso`.
 */
function vaciarCarrito() {
    while (lista.firstChild){
        lista.removeChild(lista.firstChild);

    }
    return false;
}

